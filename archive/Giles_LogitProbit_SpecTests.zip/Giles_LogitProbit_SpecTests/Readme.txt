LM Test of Logistic Against Burr Type II

The Logit model will be mis-specified, and the MLE's of the parameters will be inconsistent, 
if the underlying distribution is asymmetric. The Logistic distribution is nested within the
Burr Type II family of distributions, whose p.d.f.'s may be symmetric or skewed to the left
or to the right, depending on the value of the shape parameter (K > 0). The Logistic
distribution is nested within that family, and arises when K = 1. This LM test is for the null
hypothesis, H0: K = 1, against HA: K ≠ 1. Asymptotically, the LM test statistic is Chi-Square
with 1 degree of freedom, under the null, so we reject H0 in favour of HA if the LM test
statistic exceeds the appropriate χ2(1)(α) critical value.

Workfile: Logistic_Burr.wf1
Program file: Logistic_Burr.prg
References: Poirier (1980); Thomas (1993). 